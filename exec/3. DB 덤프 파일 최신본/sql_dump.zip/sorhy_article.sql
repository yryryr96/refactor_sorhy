-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 43.202.51.52    Database: sorhy
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `article`
--

DROP TABLE IF EXISTS `article`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `article` (
  `article_id` bigint NOT NULL AUTO_INCREMENT,
  `category` varchar(255) DEFAULT NULL,
  `content` varchar(255) DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL,
  `img_url` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `view_count` int NOT NULL,
  `user_id` bigint DEFAULT NULL,
  PRIMARY KEY (`article_id`),
  KEY `FKbc2qerk3l47javnl2yvn51uoi` (`user_id`),
  CONSTRAINT `FKbc2qerk3l47javnl2yvn51uoi` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `article`
--

LOCK TABLES `article` WRITE;
/*!40000 ALTER TABLE `article` DISABLE KEYS */;
INSERT INTO `article` VALUES (2,'FREE','1231313213','2023-11-11','https://ssafy-bucket.s3.ap-northeast-2.amazonaws.com/7d255c17-48e0-4a8e-9a90-3319ad8dbb85docker.png','제목',69,1),(3,'COMPANY','기무리~','2023-11-15','https://ssafy-bucket.s3.ap-northeast-2.amazonaws.com/b032779f-bab9-49b9-8e39-b54441630d0cchr2.png','김호찌',2,1),(4,'COMPANY','ㅋㅋㅋ','2023-11-15','https://ssafy-bucket.s3.ap-northeast-2.amazonaws.com/ed5aea3d-ee55-423b-a99c-fe951c7b03eechr8.png','안농',4,1),(5,'COMPANY','ㅋㅋㅋ','2023-11-15','https://ssafy-bucket.s3.ap-northeast-2.amazonaws.com/bd2062a7-b902-47be-9333-9e4358914b8cchr9.png','ㅋㅋㅋㅋㅋ',22,1),(6,'FREE','ㅋㅋㅋ','2023-11-15','https://ssafy-bucket.s3.ap-northeast-2.amazonaws.com/91e670de-637f-49d5-b84b-489831e6bb62chr7.png','ㅋㅋㅋㅋ',20,1),(7,'FREE','1231313213','2023-11-15','https://ssafy-bucket.s3.ap-northeast-2.amazonaws.com/7a75ac6d-493c-4ccf-81bb-00efc66b35d3mouse.jfif','회사 게시판1',12,1),(8,'FREE','1231313213','2023-11-15',NULL,'회사 게시판1',40,1),(9,'FREE','ㄱㄱ','2023-11-15',NULL,'ㄱㄱ',24,1),(10,'FREE','ㅋㅋㅋㅋ','2023-11-15','https://ssafy-bucket.s3.ap-northeast-2.amazonaws.com/ce5320a6-a409-49fa-81b2-8941627d2d1achr7.png','ㅋㅋㅋ',175,1),(11,'TIP','ㄴㅇㄴㅇ','2023-11-15',NULL,'ㄴㅇㄴㅇ',34,1),(16,'COMPANY','ㄴㄴㄴㅁ','2023-11-16',NULL,'ㅋㅋㅋㅋㅋㅇㅇ',2,1);
/*!40000 ALTER TABLE `article` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-16 17:00:43
