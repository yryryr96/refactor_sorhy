-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 43.202.51.52    Database: sorhy
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `game_result`
--

DROP TABLE IF EXISTS `game_result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_result` (
  `game_result_id` bigint NOT NULL AUTO_INCREMENT,
  `character_id` bigint DEFAULT NULL,
  `created_at` varchar(255) DEFAULT NULL,
  `score` int NOT NULL,
  `team` varchar(255) DEFAULT NULL,
  `winner` bit(1) NOT NULL,
  `game_id` bigint NOT NULL,
  `user_id` bigint NOT NULL,
  PRIMARY KEY (`game_result_id`),
  KEY `FKg7hnlts78dmtl1nqjleq4v1ku` (`game_id`),
  KEY `FKeyd08wk372kj984d6ddhw5e5k` (`user_id`),
  CONSTRAINT `FKeyd08wk372kj984d6ddhw5e5k` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FKg7hnlts78dmtl1nqjleq4v1ku` FOREIGN KEY (`game_id`) REFERENCES `game` (`game_id`)
) ENGINE=InnoDB AUTO_INCREMENT=43 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_result`
--

LOCK TABLES `game_result` WRITE;
/*!40000 ALTER TABLE `game_result` DISABLE KEYS */;
INSERT INTO `game_result` VALUES (1,1,'2023-11-11 21:04',150,'RED',_binary '',1,1),(2,1,'2023-11-12 01:27',150,'BLUE',_binary '',1,2),(3,1,'2023-11-12 01:28',150,'RED',_binary '',1,3),(4,1,'2023-11-12 01:29',150,'BLUE',_binary '',1,4),(5,10,'2023-11-12 13:37',946,'RED',_binary '',2,6),(6,5,'2023-11-13 09:59',135900,'RED',_binary '',12,6),(7,6,'2023-11-13 10:52',200,'BLUE',_binary '',13,1),(8,8,'2023-11-13 10:59',200,'RED',_binary '\0',14,1),(9,5,'2023-11-13 11:17',132300,'RED',_binary '',12,6),(10,5,'2023-11-13 15:32',129700,'RED',_binary '',15,6),(11,5,'2023-11-13 15:33',940,'RED',_binary '',16,6),(12,1,'2023-11-13 17:16',200,'RED',_binary '',17,1),(13,1,'2023-11-13 17:18',200,'RED',_binary '',18,1),(14,1,'2023-11-13 17:20',200,'RED',_binary '',18,1),(15,1,'2023-11-13 17:21',250,'RED',_binary '',18,1),(16,5,'2023-11-14 09:22',133400,'RED',_binary '',19,11),(17,1,'2023-11-14 10:43',132800,'RED',_binary '',25,11),(18,1,'2023-11-14 17:20',200000,'RED',_binary '',18,1),(19,1,'2023-11-14 17:20',200000,'RED',_binary '',30,1),(20,1,'2023-11-14 17:20',200000,'RED',_binary '',32,1),(21,2,'2023-11-14 17:21',940,'RED',_binary '',31,6),(22,1,'2023-11-15 14:44',200000,'RED',_binary '\0',32,1),(23,2,'2023-11-16 16:35',50000,'RED',_binary '',36,19),(24,4,'2023-11-16 16:35',20000,'RED',_binary '\0',37,19),(25,6,'2023-11-16 16:35',120000,'RED',_binary '',38,19),(26,6,'2023-11-16 16:37',10000,'RED',_binary '',39,19),(27,6,'2023-11-16 16:37',101000,'RED',_binary '',40,19),(29,6,'2023-11-16 16:43',10100,'RED',_binary '',41,20),(30,6,'2023-11-16 16:43',110100,'RED',_binary '',42,20),(31,6,'2023-11-16 16:43',115670,'RED',_binary '',43,20),(32,1,'2023-11-16 16:43',121347,'RED',_binary '',44,20),(33,9,'2023-11-16 16:43',113470,'RED',_binary '',45,20),(34,9,'2023-11-16 16:46',111470,'RED',_binary '',46,21),(35,9,'2023-11-16 16:46',121470,'RED',_binary '',46,21),(36,9,'2023-11-16 16:46',123370,'RED',_binary '',47,21),(37,9,'2023-11-16 16:46',213370,'RED',_binary '',48,21),(40,9,'2023-11-16 16:53',115210,'RED',_binary '',49,22),(41,5,'2023-11-16 16:53',112210,'RED',_binary '',50,22),(42,7,'2023-11-16 16:53',162210,'RED',_binary '',51,22);
/*!40000 ALTER TABLE `game_result` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-16 17:00:45
