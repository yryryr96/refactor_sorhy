-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 43.202.51.52    Database: sorhy
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `login_history`
--

DROP TABLE IF EXISTS `login_history`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `login_history` (
  `id` bigint NOT NULL AUTO_INCREMENT,
  `login_dt` varchar(255) DEFAULT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=73 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `login_history`
--

LOCK TABLES `login_history` WRITE;
/*!40000 ALTER TABLE `login_history` DISABLE KEYS */;
INSERT INTO `login_history` VALUES (1,'2023-11-11 21:04:32','ssafy123'),(2,'2023-11-12 01:27:25','enemy123'),(3,'2023-11-12 01:28:42','team123'),(4,'2023-11-12 01:29:07','enemy2'),(5,'2023-11-12 13:36:05','test123'),(6,'2023-11-12 13:36:33','wlsgud4084'),(7,'2023-11-12 19:36:21','wlsgud4084'),(8,'2023-11-12 19:39:13','sorhy123'),(9,'2023-11-12 20:53:37','sorhy123'),(10,'2023-11-13 08:34:40','test123'),(11,'2023-11-13 09:47:26','wlsgud4084'),(12,'2023-11-13 10:50:53','ssafy123'),(13,'2023-11-13 14:52:23','wlsgud4084'),(14,'2023-11-13 15:22:24','wlsgud4084'),(15,'2023-11-13 15:51:15','test1234'),(16,'2023-11-13 15:52:54','test333'),(17,'2023-11-13 15:54:58','test4444'),(18,'2023-11-13 17:05:44','ssafy123'),(19,'2023-11-13 17:40:42','test123'),(20,'2023-11-14 09:07:30','wlsgud4084'),(21,'2023-11-14 09:11:11','test4444'),(22,'2023-11-14 09:17:30','test4444'),(23,'2023-11-14 09:20:59','test4444'),(24,'2023-11-14 10:24:54','wlsgud4084'),(25,'2023-11-14 10:25:06','test4444'),(26,'2023-11-14 10:37:33','test4444'),(27,'2023-11-14 11:23:54','test4444'),(28,'2023-11-14 12:33:07','sorhy123'),(29,'2023-11-14 12:33:21','sorhy123'),(30,'2023-11-14 12:33:54','sorhy123'),(31,'2023-11-14 14:43:48','ssafy123456'),(32,'2023-11-14 14:50:46','wlsgud4084'),(33,'2023-11-14 15:00:57','wlsgud4084'),(34,'2023-11-14 17:19:43','ssafy123'),(35,'2023-11-14 17:20:51','wlsgud4084'),(36,'2023-11-14 17:21:34','qwer1234'),(37,'2023-11-15 09:44:21','test4444'),(38,'2023-11-15 09:44:54','test4444'),(39,'2023-11-15 09:48:24','test4444'),(40,'2023-11-15 09:53:11','test4444'),(41,'2023-11-15 10:03:57','test4444'),(42,'2023-11-15 10:07:08','test4444'),(43,'2023-11-15 10:08:51','test4444'),(44,'2023-11-15 10:29:40','test4444'),(45,'2023-11-15 10:31:32','test4444'),(46,'2023-11-15 10:33:49','test4444'),(47,'2023-11-15 11:47:28','ssafy123'),(48,'2023-11-15 11:54:26','ssafy123'),(49,'2023-11-15 14:51:01','ssafy123'),(50,'2023-11-15 15:23:03','test4444'),(51,'2023-11-15 15:41:14','test4444'),(52,'2023-11-15 16:04:13','test4444'),(53,'2023-11-15 16:14:39','test4444'),(54,'2023-11-15 16:15:39','ssafy123'),(55,'2023-11-15 16:22:27','ssafy123'),(56,'2023-11-15 16:25:44','ssafy123'),(57,'2023-11-15 16:26:27','ssafy123'),(58,'2023-11-15 17:01:50','wlsgud4084'),(59,'2023-11-15 17:02:19','test4444'),(60,'2023-11-15 17:15:52','ssafy123'),(61,'2023-11-15 17:16:44','wlsgud4084'),(62,'2023-11-15 17:49:22','ssafy123'),(63,'2023-11-16 09:25:49','dhdh12'),(64,'2023-11-16 11:59:32','ssafy123'),(65,'2023-11-16 12:01:07','ssafy123'),(66,'2023-11-16 14:11:21','ssafy123'),(67,'2023-11-16 14:35:40','dhdh12'),(68,'2023-11-16 16:34:29','ssafy'),(69,'2023-11-16 16:40:50','tjwjdgml12'),(70,'2023-11-16 16:46:02','dlwlsugd5683'),(71,'2023-11-16 16:47:33','shckdgus3447'),(72,'2023-11-16 16:56:25','rlaskadn111');
/*!40000 ALTER TABLE `login_history` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-16 17:00:42
