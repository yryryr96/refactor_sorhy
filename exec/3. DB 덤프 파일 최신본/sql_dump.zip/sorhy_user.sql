-- MySQL dump 10.13  Distrib 8.0.34, for Win64 (x86_64)
--
-- Host: 43.202.51.52    Database: sorhy
-- ------------------------------------------------------
-- Server version	8.0.34

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` bigint NOT NULL AUTO_INCREMENT,
  `lose` int NOT NULL,
  `nickname` varchar(255) DEFAULT NULL,
  `password` varchar(255) DEFAULT NULL,
  `total_score` int NOT NULL,
  `win` int NOT NULL,
  `win_percentage` float NOT NULL,
  `company_id` bigint DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `UK_n4swgcf30j6bmtb4l4cjryuym` (`nickname`),
  KEY `FK2yuxsfrkkrnkn5emoobcnnc3r` (`company_id`),
  CONSTRAINT `FK2yuxsfrkkrnkn5emoobcnnc3r` FOREIGN KEY (`company_id`) REFERENCES `company` (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,2,'ssafy123','$2a$10$C785LmklGQU5sPbk6h3ooe7r6MWgUAzWLd9/rwzPgieVAGMoTjVPO',801400,9,81.8182,1),(2,0,'enemy123','$2a$10$bDDiuskHCO9UMrY33qKjbujl55WIW9ATXlbbyE2V85.865PPb/S6e',150,1,100,1),(3,0,'team123','$2a$10$UjdJvYjDjcQrJBnEFZ5Bz.oaSMQi1vcR4.d1/w/tBTa0Wg7uuAMSm',150,1,100,1),(4,0,'enemy2','$2a$10$aQl7fn2Y5S0wOaDK4kK4eeCKhUtO4JxFL0SJMXzsaxtVLiqIhp43a',150,1,100,1),(5,0,'test123','$2a$10$dOTYLms/1dlBrYe0kMrsde3Q7K.ImAkix62KN/Mws3sBQRPPEjXRC',0,0,0,1),(6,0,'wlsgud4084','$2a$10$pnSHcceNdrAb9Jgfqg26M.ONe9JUy9Oly/YXxMTAq1uH1jvjia5.G',400726,6,100,1),(7,0,'gogogogo','$2a$10$Cmdmn.ztxNqO52LITgHnOu.CIueHmYVl1rzteBvLiFWYnOrxJtNym',0,0,0,1),(8,0,'sorhy123','$2a$10$ElF2De8iy0nBCBRcOkorAenmhgBValZUpeKqVLb/lk9JNFOmmjNDO',0,0,0,3),(9,0,'test1234','$2a$10$u4FemfaaslJlzRBDHhZ5oOTuq.5n7nJyueaDi31JjcIZhH1yx7S.2',0,0,0,1),(10,0,'test333','$2a$10$Bw1RapIULKIaAK.P7t/dyeT06FPfTdsRRq5Gmgu9s2KREx65MMOvS',0,0,0,6),(11,0,'test4444','$2a$10$SJJqD2CdevIJYVO0nLUENuludvxnJdXgvVQ3PoCmcpNCWbL4RamxW',266200,2,100,6),(12,0,'tttt123','$2a$10$NE222aWC0IwaDyLZuGyHxOIZma2wjjQx01OfM5f0cQSvdUVreVUha',0,0,0,3),(13,0,'ssafy123456','$2a$10$6ukSwSKwYMr3XupW8gHZCetPfwXfCqcEWoRKnHt0x7B48kb9XGXYS',0,0,0,2),(14,0,'dkdk12','$2a$10$e09xW8Iy2p2oDaMsaufRG.4alw4cxTQkuzVrXyPKrkV1.ptXjbc8G',0,0,0,4),(15,0,'coach','$2a$10$pLcVgBfqq1zsCMXx/clBteHHiG.vSj/vCV2qPcluEwlmySAQYSNo2',0,0,0,3),(16,0,'qwer1234','$2a$10$HjlDWaWSWPkK2nKrY7KUlOxCDffpf2KIVAspqHgM/plZVjMk0pD0K',0,0,0,4),(17,0,'ssafy1010','$2a$10$bLkGNvisqqRHG9GJFhePze5J3.2UJYITWYngQ3BBZoM2nugvFB2bq',0,0,0,2),(18,0,'dhdh12','$2a$10$noi2JSPIsS9Tfq2E14smfuvaYKqZqgo9SksZnrs/5Kc34BNUlkq7W',0,0,0,5),(19,1,'ssafy','$2a$10$4h3EZImMjrZBBPaS5qTkPOSUqEDLCfvsTpNloU47N1FRc.l5Wyb3y',301000,4,80,3),(20,0,'tjwjdgml12','$2a$10$JynaVntbo26EBEE8E6x77u2RLbxkutsa/toEpDkekSN1SikQeYGJG',1572910,6,100,3),(21,0,'dlwlsugd5683','$2a$10$M2.r36i6a8CKWEqYDbqrzuH.xun1Za2jGflP1Xz7Cr/y8mksKl8z.',569680,4,100,3),(22,0,'shckdgus3447','$2a$10$PGTijVhB3BtGstDizpnPP.e37uXwQMXHi.CutMIunJyuyA2CjMUtu',715170,5,100,4),(23,0,'rlaskadn111','$2a$10$k.uaVcoRhjkvnaLYguGAmu3pXNGM5m0Kzfn7sYa8qaIq/H9Xd0JA2',0,0,0,2);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2023-11-16 17:00:43
